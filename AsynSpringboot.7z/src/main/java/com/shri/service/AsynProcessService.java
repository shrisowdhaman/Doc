package com.shri.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * @author Shrisowdhaman on 2019-12-13.
 */
@Service
public class AsynProcessService {


    @Async("processExecutor")
    public void startProcess() throws InterruptedException {
        System.out.println("Hai Started ");
        Thread.sleep(2000L);
        System.out.println("Hai End ");
    }
}
