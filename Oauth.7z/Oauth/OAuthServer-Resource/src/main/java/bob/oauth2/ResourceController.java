package bob.oauth2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Shrisowdhaman on 2020-02-19.
 */
@RestController
public class ResourceController {

    @RequestMapping("/public")
    public String publico() {
        return "Un Authorization - Public can access this page ";
    }
    @RequestMapping("/private")
    public String privada() {

        return "Authorization page";
    }
    @RequestMapping("/admin")
    public String admin() {

        return "Authorization page - Admin";
    }
}
