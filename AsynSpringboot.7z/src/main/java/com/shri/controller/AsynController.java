package com.shri.controller;

import com.shri.service.AsynProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.core.MediaType;

/**
 * @author Shrisowdhaman on 2019-12-13.
 */

@RestController
@RequestMapping("/asyns")
public class AsynController {

    @Autowired
    private AsynProcessService asynProcessService;

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON)
    public String doSomeWork(@PathVariable("id") final String id) {
        try {
            asynProcessService.startProcess(); // time consuming operation
        }catch (Exception err) {
            System.out.println(err);
        }
        return "Your request has been queued." + id;
    }
}
